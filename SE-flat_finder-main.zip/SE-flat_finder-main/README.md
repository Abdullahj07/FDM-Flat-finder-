# SE-flat_finder

Welcome to the Flat Finder Web app
This is a project i did in my 2nd year with a group of 4 other members
Please feel free to play around and test

Admin:
email:admin@gmail.com

password: admin

employee:
email:employee@gmail.com

password: employee


Functions implemented in the Flat Finder Web app:
1) Login
2) Create listing
3) Search for lsiting
4) filter through listings
5) admin functionalities (deleting listings)
6) chat function

This project was supported and created for FDM to be a Flat finder for consultants that are travelling to different contries/locations and therefore would need accomodation.

There were a few functionalities that we didn't manage to include that would imporve on the project:
1) Booking system
2) User timeout / Ban
    
