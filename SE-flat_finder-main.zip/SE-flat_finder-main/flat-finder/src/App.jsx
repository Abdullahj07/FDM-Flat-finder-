import {Landingpage} from './pages/Landingpage.jsx'
import {Signin} from './pages/Signin.jsx'
import { Signup } from './pages/Signup.jsx';
import { Dashboard } from './pages/Dashboards/Dashboard.jsx';
import { Profile } from './pages/Profile.jsx';
import { Complaint } from './pages/Complaint.jsx';
import { AdminDashboard } from './pages/Dashboards/AdminDashboard.jsx';
import { LandlordDashboard } from './pages/Dashboards/LandlordDashboard.jsx';
import { Chat } from './pages/Chat.jsx';
import { MOL } from './pages/MOL.jsx'
import { SearchPage } from './pages/SearchPage.jsx'
import CurrentListings from './pages/CurrentListings.jsx'
import ViewComplaint from './pages/ViewComplaint.jsx'
import RemoveListings from './pages/RemoveListings.jsx';
import Favorites from './pages/Favorites.jsx';
//import { EditFlatListings } from './pages/EditFlatListings.jsx'
import UKMOL from './pages/UKMOL.jsx';



import { SearchResults } from './pages/SearchResults.jsx';
import { SetupProfile } from './pages/SetupProfile.jsx';


function App() {
  let current_page
  switch (window.location.pathname) {
    case '/':
      current_page = <Landingpage />
      break;
    case '/Signin':
      current_page = <Signin />
      break;
    case '/Signup':
      current_page = <Signup />
      break;
    case '/Dashboard':
      current_page = <Dashboard />
      break;
    case '/AdminDashboard':
      current_page = <AdminDashboard />
      break;
    case '/LandlordDashboard':
      current_page = <LandlordDashboard />
      break;
    case '/Profile':
      current_page = <Profile />
      break;
    case '/Complaint':
      current_page = <Complaint />
      break;
    case '/Chat':
      current_page = <Chat />
      break;
    case '/MOL':
      current_page = <MOL />
      break;
    case '/CurrentListings':
      current_page = <CurrentListings />
      break;
    case '/SearchPage':
      current_page = <SearchPage />
      break;
    case '/SearchResults':
      current_page = <SearchResults />
      break;
    /*case '/EditFlatLisitngs':
      current_page = <EditFlatListings />
      break;
      */
    case '/Search':
      current_page = <SearchPage />
      break;
    case '/SetupProfile':
      current_page = <SetupProfile />;
      break;
    case '/ViewComplaint':
      current_page = <ViewComplaint />;
      break;
    case '/RemoveListings':
      current_page =  <RemoveListings />;
      break;
    case '/Favorites':
      current_page =  <Favorites />;
      break;
    case '/UKMOL':
      current_page =  <UKMOL />;
      break;

  }
  return (
    <>
      {current_page}
    </>

  )
}

export default App

