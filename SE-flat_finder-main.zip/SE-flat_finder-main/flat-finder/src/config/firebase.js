// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getAuth} from 'firebase/auth'
import {getFirestore} from 'firebase/firestore'

const firebaseConfig = {
  apiKey: "AIzaSyDCFfy4l0CUGBPnvWu2GETdZ04owB8_eos",
  authDomain: "flat-finder-g55.firebaseapp.com",
  projectId: "flat-finder-g55",
  storageBucket: "flat-finder-g55.appspot.com",
  messagingSenderId: "780007977073",
  appId: "1:780007977073:web:821f3a2bab955910812bd0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app)

export const db = getFirestore(app)