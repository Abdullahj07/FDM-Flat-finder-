import { useState, useEffect } from 'react';
import { collection, getDocs, serverTimestamp ,addDoc ,query, where, orderBy } from 'firebase/firestore';
import { auth, db } from '../config/firebase';
import './Chat.css';

export const Chat = () => {
  const [users, setUsers] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [message, setMessage] = useState('');
  const [currentUser, setCurrentUser] = useState(null);
  const [conversation, setConversation] = useState([]);
  const urlParams = new URLSearchParams(window.location.search);
  const userID = urlParams.get('userID');



  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(user => {
      setCurrentUser(user);
      if (user) {
        fetchUsers(user);
      } else {
        setUsers([]);
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (currentUser && selectedUserId) {
      fetchMessages(currentUser.uid, selectedUserId);
    }
  }, [currentUser, selectedUserId]);

  // Fetch messages when userID changes
  useEffect(() => {
    if (userID) {
      handleUserClick(userID);
    }
  }, [userID]);

  const fetchUsers = async (user) => {
    try {
      const collRef = collection(db, 'Users');
      const querySnapshot = await getDocs(collRef);
      const userList = [];

      querySnapshot.forEach((doc) => {
        const userData = doc.data();
        if (userData.email !== user.email) {
          userList.push({ id: doc.id, ...userData });
        }
      });

      setUsers(userList);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };
  const fetchMessages = async (userId, selectedUserId) => {
    try {
      const messagesRef = collection(db, 'messages');
      const q = query(messagesRef, where('senderID', 'in', [userId, selectedUserId]), where('receiverID', 'in', [userId, selectedUserId]), orderBy('timestamp'));

      const querySnapshot = await getDocs(q);
      const messageList = [];

      querySnapshot.forEach((doc) => {
        messageList.push({ id: doc.id, ...doc.data() });
      });

      setConversation(messageList);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const handleUserClick = (userId) => {
    setSelectedUserId(userId);
    if (currentUser && userId) {
        fetchMessages(currentUser.uid, userId);
      }
  };

  const sendMessage = async () => {
    try {
      if (!currentUser) {
        throw new Error('User not logged in');
      }

      const messagesRef = collection(db, 'messages');

      // Add message to Firestore
      await addDoc(messagesRef, {
        senderID: currentUser.uid,
        receiverID: selectedUserId,
        timestamp: serverTimestamp(),
        message: message
      });

      setMessage('');

      if (currentUser && selectedUserId) {
        fetchMessages(currentUser.uid, selectedUserId);
      }

    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  if (!currentUser) {
    return <div>Please log in to view and send messages.</div>;
  }

  const getUserEmail = (userId) => {
    if (!userId) return null;
    
    if (currentUser && userId === currentUser.uid) {
      return currentUser.email;
    }
  
    const user = users.find(user => user.userID === userId);
    return user ? user.email : null;
  };

  const user_type = async () => {
    try {
        const currentUser = auth.currentUser;
        if (!currentUser) {
            throw new Error('User not logged in');
        }

        const currentEmail = currentUser.email;
        console.log(currentEmail);

        const collRef = collection(db, 'Users');
        const q = query(collRef, where('email', '==', currentEmail));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
            const doc = querySnapshot.docs[0];
            const userType = doc.data().usertype;
            return userType;
        } else {
            throw new Error('No matching document found');
        }
        } catch (error) {
            console.error('Error retrieving user type:', error);
            return null;
        }
    };

    const backBtn = async () => {
        try {
          const userType = await user_type();
    
          switch (userType) {
            case 'employee':
              window.location.href = '/Dashboard';
              break;
            case 'admin':
              window.location.href = '/AdminDashboard';
              break;
            case 'landlord':
              window.location.href = '/LandlordDashboard';
              break;
            default:
              console.error('Unknown user type:', userType);
          }
        } catch (error) {
          console.error('Error retrieving user type:', error);
        }
      };
  
  return (
    <div className="chat-container">
      <div className="user-list">
        <h2 className='user-title'>Select a User:</h2>
        <ul>
          {users.map((user) => (
            <li key={user.id} onClick={() => handleUserClick(user.userID)} className={user.userID === selectedUserId ? 'user-item selected' : 'user-item'}>
              {user.email}
            </li>
          ))}
        </ul>
      </div>
      <div className="chat-area">
        <button className="back-button" onClick={backBtn}>Back</button>
        <div className="chat-header">
          <h2 className="selected-user-id">{getUserEmail(selectedUserId)}</h2>
        </div>
        <div className="messages">
          {conversation.map((msg) => (
            <div key={msg.id} className={`message ${msg.senderID === currentUser.uid ? 'sent-message' : 'received-message'}`}>
              <strong className="message-sender">{getUserEmail(msg.senderID)}<br></br></strong>
              <span className="message-content">{msg.message}<br></br></span>
              <span className="message-timestamp">{msg.timestamp.toDate().toLocaleString()}</span>
            </div>
          ))}
        </div>
        <div className="message-input">
          <input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your message..."
            className="input-field"
          />
          <button onClick={sendMessage} className="send-button">Send</button>
        </div>
      </div>
    </div>
  );
};




