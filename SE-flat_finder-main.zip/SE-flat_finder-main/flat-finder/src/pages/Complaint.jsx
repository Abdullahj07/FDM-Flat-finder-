import { useState, useEffect } from "react";
import './Complaint.css'
import { collection, serverTimestamp , addDoc, query, where, getDocs } from 'firebase/firestore';
import { auth, db } from '../config/firebase';
import fdmLogo from "../images/landingpage_img/fdm_logo.png";
import profilePic from "../images/profile_img/profile_pic.png";
import {signOut} from "firebase/auth";


export const Complaint = () => {
    const [selectedOption, setSelectedOption] = useState('');
    const [complaint, setComplaint] = useState('');
    const [Reason, setReason] = useState('');
    const [userEmail, setUserEmail] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [userType, setUserType] = useState(null);
    const [landlordUserEmails, setLandlordUserEmails] = useState([]);
    const [selectedLandlord, setSelectedLandlord] = useState('Select a landlord');


    // Check if user is logged in and get user type
    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged(async user => {
            setCurrentUser(user);

            if (user) {
                // Fetch user type from Firestore
                const q = query(collection(db, "Users"), where("userID", "==", user.uid));
                const querySnapshot = await getDocs(q);
                const userDoc = querySnapshot.docs[0];
                if (userDoc) {
                    setUserType(userDoc.data().usertype);
                }
            } else {
                setUserType(null);
            }
        });

        return unsubscribe;
    }, []);

    // Get the user's email
    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                setUserEmail(user.email);
            } else {
                setUserEmail(null);
            }
        });

        return () => unsubscribe();
    }, []);

    // Logout function
    const logout = async () => {
        try {
            await signOut(auth);
            window.location.href = '/';
        } catch (err) {
            console.log(err);
        }
    };
    //Choose Reason
    const handleSelectChange = async (event) => {
        setSelectedOption(event.target.value);

        //get Landlord user emails
        if (event.target.value === 'Landlord') {
            const q = query(collection(db, "Users"), where("usertype", "==", "landlord"));
            const querySnapshot = await getDocs(q);
            const landlordUserEmails = querySnapshot.docs.map(doc => doc.data().email);
            setLandlordUserEmails(landlordUserEmails); // Store the landlord user emails in state
            setSelectedLandlord(null); // Reset selectedLandlord
        }
    }
    const handleLandlordChange = (event) => {
        if (event.target.value !== 'Select a landlord') {
            setSelectedLandlord(event.target.value);
        }
    }

    // Form Submission
    const handleSubmit = async (event) => {
        event.preventDefault();

        if (!currentUser) {
            console.error('No current user found.');
            return;
        }

        // If selected option is 'Others', use the value from the Reason field
        const reason = selectedOption === 'Others' && Reason ? Reason : selectedOption;



        // Add a new Complaint to database
        try {
            const docRef = await addDoc(collection(db, "Complaints"), {
                userID: currentUser.uid,
                userEmail: userEmail,
                receiverEmail: selectedOption === 'Landlord' ? selectedLandlord : null,
                reason: reason,
                details: complaint,
                timestamp: serverTimestamp(),
                status: false // Set status to false
            });
            console.log('Complaint submitted with ID: ', docRef.id);
            alert('Complaint submitted successfully!'); // Add this line
            clearForm();
        } catch (error) {
            console.error('Error submitting complaint: ', error);
        }
    }

    // Clear the form
    const clearForm = () => {
        setSelectedOption('');
        setComplaint('');
        setReason('');
    }

    return (
        <div className='complain'>
            {currentUser ? (
                <>
                    <div className="navBar">
                        <div className="fdmLogo"><a href='/'><img src={fdmLogo} alt="FDM Logo"></img></a></div>
                        <a href='/Profile' className="profileScrnBtn">Profile</a>
                        {userType === 'admin' && <a href='/RemoveListings' className="ListingScrnBtn">Listing</a>}
                        {userType === 'landlord' && <a href='/MOL' className='MOLScrnBtn'>Make Own Listing</a>}
                        {userType === 'employee' && <a href='/Search' className='searchScrnBtn'>Search</a>}
                        {userType === 'employee' && <a href='/MOL' className="searchScrnBtn">Listing</a>}
                        <a href='/Complaint' className="complaintsScrnBtn">Complaints</a>
                        <a href='/Chat' className='Chatbtn'>Chat</a>
                        <div className='userinfo'>
                            <p className='userEmail'>{userEmail}</p>
                            <div className='dashboardProfPic'><a href='/Profile'><img src={profilePic} alt="Profile pic"/></a></div>
                        </div>
                        <button onClick={logout} className="logOutBtn">Log Out</button>
                    </div>

                    <h1>Complaint Form</h1>
                    <form onSubmit={handleSubmit}>
                        <label htmlFor='Complaint'>Reason for complaint</label>
                        <select name='Complaint' id='Complaint' value={selectedOption} onChange={handleSelectChange}
                                required>
                            <option value='' disabled>Select a reason</option>
                            <option value='Landlord'>Landlord</option>
                            <option value='flat'>Flat</option>
                            <option value='Website'>Website</option>
                            <option value='Others'>Others</option>
                        </select>

                        {selectedOption === 'Others' &&
                            <textarea
                                id='reason'
                                placeholder="Please specify"
                                value={Reason}
                                onChange={(e) => setReason(e.target.value)}
                                required>
                        </textarea>
                        }

                        {selectedOption === 'Landlord' && landlordUserEmails.length > 0 &&
                            <select name='Landlord' id='Landlord' onChange={handleLandlordChange} required>
                                <option value='Select a landlord' disabled selected>Select a landlord</option>
                                {landlordUserEmails.map((id, index) => (
                                    <option key={index} value={id}>{id}</option>
                                ))}
                            </select>
                        }

                        <label>Please Provide any details:</label>
                        <textarea
                            name='Details'
                            id='Details'
                            placeholder="Please type your complaint"
                            value={complaint}
                            onChange={(e) => setComplaint(e.target.value)}
                            required>
                    </textarea>
                        <div className='buttons'>
                            <button type='submit'> Submit</button>
                            <button id='clear' type='button' onClick={clearForm}> Clear</button>
                        </div>
                    </form>
                </>
            ) : (
                <div>User not logged in</div>
            )}
        </div>
    );
}
