import React, { useState, useEffect } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../config/firebase";
import { Link } from "react-router-dom";
import "./CurrentListings.css";

const CurrentListings = () => {
  const [listings, setListings] = useState([]);

  useEffect(() => {
    fetchListings();
  }, []);

  const fetchListings = async () => {
    try {
      const listingsRef = collection(db, "listings");
      const querySnapshot = await getDocs(listingsRef);
      const listingsArray = [];

      querySnapshot.forEach((doc) => {
        const data = doc.data();
        let skipListing = false;

        for (const key in data) {
          if (!data[key] || (typeof data[key] === "string" && data[key].trim() === "")) {
            skipListing = true;
            break;
          }
        }

        if (!skipListing) {
          listingsArray.push({ id: doc.id, ...data, currentImageIndex: 0 });
        }
      });

      setListings(listingsArray);
    } catch (error) {
      console.error("Error fetching listings:", error);
    }
  };

  return (
    <div>
      <a href='/LandlordDashboard' className='LandlordDashboardScrnBtn'>Return To Dashboard</a>
      <h2 className="listings-heading">All Listings</h2>
      {listings.map((listing, index) => (
        <div key={listing.id} className="listing-card">
          <h3 className="listing-title">{listing.title}</h3>
          <div className="listing-details">
            <p>Description: {listing.description}</p>
            <p>Price Per Month £: {listing.price}</p>
            <p>Location: {listing.location}</p>
            <p>Number of Bedrooms: {listing.bedrooms}</p>
            <p>Number of Bathrooms: {listing.bathrooms}</p>
            <p>Length of Stay: {listing.shortOrLongStay}</p>
            <p>Is FDM Host: {listing.isFDMHost}</p> {/* Display Is FDM Host */}
            <p>Postcode: {listing.postcode}</p> {/* Display Postcode */}
            <div>
              <h4 className="image-header">Image/s</h4>
              <div className="image-container">
                {listing.imagePreviews.map((image, imageIndex) => (
                  <img
                    key={imageIndex}
                    src={image}
                    alt={`Listing Image ${imageIndex}`}
                    className="listing-image"
                    style={{ maxWidth: "200px", maxHeight: "200px" }}
                  />
                ))}
              </div>
            </div>
            <span><b>Link:</b> <a href={listing.link} target="_blank" rel="noopener noreferrer">{listing.link}</a></span>
            {listing.imagePreviews.length > 1 && (
              <div className="image-navigation">
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default CurrentListings;


