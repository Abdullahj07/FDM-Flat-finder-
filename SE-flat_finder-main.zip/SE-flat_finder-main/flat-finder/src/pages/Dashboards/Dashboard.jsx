import { useState, useEffect } from 'react';
import { auth } from '../../config/firebase.js';
import { signOut } from 'firebase/auth';
import fdmLogo from '../../images/landingpage_img/fdm_logo.png'
import profilePic from '../../images/profile_img/profile_pic.png'
import './Dashboard.css'


export const Dashboard = () => {
    const [userEmail, setUserEmail] = useState(null);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                setUserEmail(user.email);
            } else {
                setUserEmail(null);
            }
        });

        return () => unsubscribe();
    }, []);

    const logout = async () => {
        try {
            await signOut(auth);
            window.location.href = '/';
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <>
            <div className="DashboardWrap">
                <div className="navBar">
                    <div className="fdmLogo"><a href='/'><img src={fdmLogo} alt="FDM Logo"></img></a></div>
                    <a href='/Profile' className="profileScrnBtn">Profile</a>
                    <a href='/SearchResults' className="searchScrnBtn">Search</a>
                    <a href='/MOL' className="searchScrnBtn">Listing</a>
                    <a href='Complaint' className="complaintsScrnBtn">Complaints</a>
                    <a href='/Chat' className='Chatbtn'>Chat</a>
                    <div className='userinfo'>
                        <p className='userEmail'>{userEmail}</p>
                        <div className='dashboardProfPic'><a href='/Profile'><img src={profilePic} alt="Profile pic"/></a></div>
                    </div>
                    {userEmail ? (
                        <button onClick={logout} className="logOutBtn">Log Out</button>
                    ) : (
                        <button onClick={() => window.location.href = "/"} className="logInBtn">Log In</button>
                    )}
                    {/* Log out button only returns to landing page, does NOT end session */}
                </div>
                <div className="dashboardContent">
                    <div className="dashboardheader">
                        <h3>Hi {userEmail},Welcome to the Dashboard</h3>
                        <h4>What would you like to do today?</h4>
                    </div>

                    <div className="boxesContainer">
                        <div className="Searchbox">
                            <a href="/SearchResults" className="searchPageBtn">Go to Search page</a>
                        </div>
                        <div className="Complaintbox">
                            <a href='/Complaint' className="ComplaintPageBtn">Create Complaints</a>
                        </div>
                        <div className="Chatbox">
                            <a href='/Chat' className='ChatPageBtn'>Start a Chat</a>
                        </div>
                        <div className="Profilebox">
                            <a href='/Profile' className="profilePageBtn">Edit your profile</a>
                        </div>
                    </div>

                </div>
            </div>
        </>
    );
};