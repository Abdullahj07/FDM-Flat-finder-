import React from "react";
import { Link } from "react-router-dom";

const EditFlatListings = () => {
  console.log("hello");
  return (
    <div>
      <h1>Hello</h1>
    </div>
  );
};

export default EditFlatListings; // Export the component


