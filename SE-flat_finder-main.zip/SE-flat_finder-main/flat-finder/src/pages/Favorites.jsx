import React, { useState, useEffect } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../config/firebase';
import './Favorites.css';

const Favorites = () => {
  const [favoriteListings, setFavoriteListings] = useState([]);

  useEffect(() => {
    const fetchFavoriteListings = async () => {
      try {
        const listingsRef = collection(db, 'listings');
        const querySnapshot = await getDocs(listingsRef);
        const favoriteListingsArray = [];

        querySnapshot.forEach((doc) => {
          const data = doc.data();
          if (data.favorite) {
            favoriteListingsArray.push({ id: doc.id, ...data });
          }
        });

        setFavoriteListings(favoriteListingsArray);
      } catch (error) {
        console.error('Error fetching favorite listings:', error);
      }
    };

    fetchFavoriteListings();
  }, []);

  return (
    <div className="favorites-container">
      <h1>Favorites</h1>
      {favoriteListings.map((listing) => (
        <div key={listing.id} className="favorite-listing">
          <h2>{listing.title}</h2>
          <p>Description: {listing.description}</p>
          <p>Price: £{listing.price}</p>
          {/* Other listing details */}
        </div>
      ))}
    </div>
  );
};

export default Favorites;

