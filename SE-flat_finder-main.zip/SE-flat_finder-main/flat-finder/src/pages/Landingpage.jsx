import React from 'react'

import FDM_logo from '../images/landingpage_img/fdm_logo.png'
import profile_pic from '../images/landingpage_img/profile_pic.png'
import menu from '../images/landingpage_img/menu.png'
import find_house from '../images/landingpage_img/find_house.png'
import linked_in from '../images/landingpage_img/linked_in.png'
import twitter from '../images/landingpage_img/twitter.png'
import github from '../images/landingpage_img/github.png'

import './Landingpage.css'


export const Landingpage = () => {

    return (
        <>
            <div id="home" className="home">
                <div className="header">
                    <img src={FDM_logo} alt="FDM-logo" className="FDM-logo" />
                    <div className="nav-btns">
                        <a href='#home'><p className="home-btn">Home</p></a>
                        <a href='#about-us'><p className="about-us-btn">About Us</p></a>
                        <a href='#footer'><p className="contact-btn">Contact</p></a>
                    </div>
                    <div className="sign-in-sign-up-btns">
                        <a href='/Signin' className="sign-in">Sign In</a>
                        <a href='/Signup' className="sign-up">Sign Up</a>
                    </div>
                    <img src={profile_pic} alt="profile-pic" className="profile-pic" />
                    <img src={menu} alt="menu" className="menu_btn" />
                </div>
                <div className="home-title-section">
                    <h1 className="home-title">Find your perfect home</h1>
                    <p className="title-description">Assisting you in finding the perfect accommodation,<br /> effortlessly discover homes abroad</p>
                    <a href='/Signin' className="mainsignin">Sign In</a>
                </div>
                
            </div>
            <div id="about-us" className="about-us">
                <h1 className="about-us-title">About Us</h1>
                <div className="about-us-content">
                    <div className="about-us-description">
                        <h2 className="welcome-title">Welcome to FDM Flat Finder!</h2>
                        <p className="welcome-description">At FDM Flat Finder, we're dedicated to simplifying the process of finding accommodation for our employees. With our user-friendly platform and personalized approach, we make relocating for work hassle-free.</p>
                        <h2 className="mission-title">Our Mission</h2>
                        <p className="mission-description">FDM Flat Finder is committed to providing our employees with convenient and reliable accommodation solutions, ensuring a smooth transition for their work assignments.</p>
                    </div>
                    <img src={find_house} alt="houses" />
                </div>
            </div>
            <div id="footer" className="footer">
                <div className="footer-title-nav">
                    <div id='fdmfooterlogo'>
                        <img src={FDM_logo} alt="FDM-logo" />
                    </div>
                    <div className="footericons">
                        <img src={linked_in} alt="linked-in" />
                        <img src={twitter} alt="twitter" />
                        <img src={github} alt="github" />
                    </div>
                </div>
                <div className='footer-desc'>
                    <div><h1>FDM Flat Finder</h1></div>
                    <div><h3>Assisting you in finding the perfect accommodation, effortlessly discover homes abroad.</h3></div>
                </div>
                <div className="footer-nav">
                    <a href="#home">Home</a>
                    <a href="#about-us">About Us</a>
                    <a href="#footer">Contact</a>
                    <a href='Signin'>Sign In</a>
                    <a href='Signup'>Sign Up</a>
                </div>
            </div>
        </>
    )
}

