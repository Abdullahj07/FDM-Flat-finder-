import React from 'react';

import { useState, useEffect } from 'react';
import { auth } from '../config/firebase';
import { signOut } from 'firebase/auth';
import { db } from '../config/firebase';
import { collection, getDocs } from 'firebase/firestore'; 

import fdmLogo from '../images/landingpage_img/fdm_logo.png';

import profilePic from '../images/profile_img/profile_pic.png';
import instagram from '../images/profile_img/instagram.png';
import twitter from '../images/profile_img/twitter.png';
import linkedin from '../images/profile_img/linked_in.png';

import "./Profile.css" // Importing CSS file for Profile styling

// Define the functional component for Profile
export const Profile = () => {

    {/* Inherited from 'Dashboard.jsx' */}
    const [userEmail, setUserEmail] = useState(null);
    const [userData, setUserData] = useState(null);

    useEffect(() => {
        // Set up a listener for changes in authentication state
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                // If user is logged in, set the email in state
                setUserEmail(user.email);

                fetchUserData(user);

            } else {
                // If no user is logged in, set the email to null
                setUserEmail(null);
            }
        });

        // Cleanup function to unsubscribe from the listener when the component unmounts
        return () => unsubscribe();
    }, []);

    // Function to handle user logout
    const logout = async () => {
        try {
            // Sign out the user
            await signOut(auth);
            // Redirect to the landing page
            window.location.href = '/';
        } catch (err) {
            // Log any errors that occur during logout
            console.log(err);
        }
    };

    const fetchUserData = async (user) => {
        try {
            const collRef = collection(db, 'Profiles');
            const querySnapshot = await getDocs(collRef);
            querySnapshot.forEach((doc) => {
                const userData = doc.data();
                if (userData['email-ad'] === user.email) {
                    setUserData(userData);
                    return;
                }
            });
        } catch (error) {
            console.error('Error fetching data', error);
            
        }
    };

    return (
        <>
            {/* Profile container */}
            <div className="profile-wrap">

                {/* Inherited from 'Dashboard.jsx' and 'Dashboard.css' */}
                <div className="navBar">
                    {/* FDM Logo */}
                    <div className="fdmLogo"><a href='/'><img src={fdmLogo} alt="FDM Logo"></img></a></div>
                    {/* Profile Link */}
                    <a href='/Profile' className="profileScrnBtn">Profile</a>
                    {/* Search Link */}
                    <a href='/SearchResults' className="searchScrnBtn">Search</a>
                    {/* Listing Link */}
                    <a href='/MOL' className="searchScrnBtn">Listing</a>
                    {/* Complaints Link */}
                    <a href='/ViewComplaint' className="complaintsScrnBtn">Complaints</a>
                    {/* Chat Link */}
                    <a href='/Chat' className='Chatbtn'>Chat</a>
                    {/* User Email */}{/* Profile Picture */}
                    <div className='userinfo'>
                        <p className='userEmail'>{userEmail}</p>
                        <div className='dashboardProfPic'><a href='/Profile'><img src={profilePic} alt="Profile pic"/></a></div>
                    </div>
                    {/* Logout Button */}
                    <button onClick={logout} className="logOutBtn">Log Out</button>
                    {/* Log out button only returns to landing page, does NOT end session */}
                </div>

                {/* Main profile section */}
                <div className="profile-main">
                    <h1 className="profile-title">Your Profile</h1>
                    <p className="profile-title-description"><img src={profilePic} alt="profile-pic" /><br />
                        <h2>{userData ? userData.name: ''}</h2>
                    </p>
                    <h2>
                        <a href='/SetupProfile' className="profile-edit-profile-btn">Edit Profile</a>
                    </h2>
                </div>
                {/* Profile information section */}
                <div className="profile-info-one">
                    {/* Work information */}
                    {/*<div className="profile-work-info">
                         <h2>Work information</h2>
                        <ul>
                            <li>Department: "IT"</li>
                            <li>Position: "General Manager"</li>
                            <li>Stationed: "UK"</li>
                        </ul> 
                     </div> */}
                    {/* Contact information */}
                    <div className="profile-contact-info">
                        <h2>Contact Info</h2>
                        <ul>
                            <li>Phone Number: {userData ? userData['phone-num'] : ''}</li>
                            <li>Email: {userData ? userData['email-ad'] : ''}</li>
                        </ul>
                    </div>
                    {/* Hobbies information */}
                    <div className="profile-hobbies">
                        <h2>Hobbies</h2>
                        <ul>    
                            <li>{userData ? userData['hobby-one'] : ''}</li>
                            <li>{userData ? userData['hobby-two'] : ''}</li>
                            <li>{userData ? userData['hobby-three'] : ''}</li>
                        </ul>
                    </div>
                    {/* Preferences information */}
                    <div className="profile-prefer">
                        <h2>Preferences</h2>
                        <ul>
                            <li>Smoking: {userData ? (userData['pref-smoke'] ? 'Yes' : 'No')  : ''}</li>
                            <li>Pets: {userData ? (userData['pref-pet'] ? 'Yes' : 'No')  : ''}</li>
                        </ul>
                    </div>
                </div>
                {/* Social media information section */}
                <div className="profile-info-two">
                    <div className="profile-soc-med">
                        <h2>Social Media</h2>
                        {/* Social media icons */}
                        <div className="profile-soc-med-links">
                            <a href="instagram.com"><img className="socmed-icon" src={instagram} alt="instagram" /></a>
                            <a href="x.com"><img className="socmed-icon" src={twitter} alt="twitter" /></a>
                            <a href="linkedin.com"><img className="socmed-icon" src={linkedin} alt="linkedin" /></a>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
