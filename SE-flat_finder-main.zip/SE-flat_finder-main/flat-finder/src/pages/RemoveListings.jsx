import { useState, useEffect } from "react";
import { collection, getDocs, doc, deleteDoc } from "firebase/firestore";
import { db } from "../config/firebase";
import "./RemoveListings.css";

const RemoveListings = () => {
    const [listings, setListings] = useState([]);

    useEffect(() => {
        fetchListings();
    }, []);

    // Fetch all listings from Firestore
    const fetchListings = async () => {
        try {
            const listingsRef = collection(db, "listings");
            const querySnapshot = await getDocs(listingsRef);
            const listingsArray = [];

            querySnapshot.forEach((doc) => {
                const data = doc.data();
                let skipListing = false;

                for (const key in data) {
                    if (!data[key] || (typeof data[key] === "string" && data[key].trim() === "")) {
                        skipListing = true;
                        break;
                    }
                }

                if (!skipListing) {
                    listingsArray.push({ id: doc.id, ...data, currentImageIndex: 0 });
                }
            });

            setListings(listingsArray);
        } catch (error) {
            console.error("Error fetching listings:", error);
        }
    };

    // Delete a listing from Firestore
    const deleteListing = async (id) => {
        const confirmation = window.confirm("Are you sure you want to delete this listing?");
        if (confirmation) {
            try {
                const listingRef = doc(db, "listings", id);
                await deleteDoc(listingRef);
                fetchListings(); // Refresh listings after a listing is deleted
            } catch (error) {
                console.error("Error deleting listing:", error);
            }
        }
    };

    return (
        <div className='ReListing'>
            <h1>All Flat Listings</h1>
            {listings.map((listing) => (
                <div key={listing.id} className="rlisting-card">
                    <h3 className="rlisting-title">{listing.title}</h3>
                    <div className="rlisting-details">
                        <p>Description: {listing.description}</p>
                        <p>Price Per Month £: {listing.price}</p>
                        <p>Location: {listing.location}</p>
                        <p>Number of Bedrooms: {listing.bedrooms}</p>
                        <p>Number of Bathrooms: {listing.bathrooms}</p>
                        <p>Length of Stay: {listing.shortOrLongStay}</p>
                    </div>
                    <button className='DeleteBtn' onClick={() => deleteListing(listing.id)}>Delete</button>
                </div>
            ))}
            <button onClick={() => window.location.href = "/AdminDashboard"} className="ReturnBtn">Return to Dashboard</button>
        </div>
    );
};

export default RemoveListings;

