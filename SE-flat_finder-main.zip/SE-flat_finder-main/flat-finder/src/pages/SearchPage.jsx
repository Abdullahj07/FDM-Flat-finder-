{/* 
    This JSX code defines the SearchPage component. 
    It includes a search page wrapper with a navigation bar inherited from the Dashboard component.
*/}

import React from 'react';

import { useState, useEffect } from 'react';
import { auth } from '../config/firebase';
import { signOut } from 'firebase/auth';

import fdmLogo from '../images/landingpage_img/fdm_logo.png';
import profilePic from '../images/profile_img/profile_pic.png';

import './SearchPage.css'; // Importing CSS file for SearchPage styling

// Define the functional component for SearchPage
export const SearchPage = () => {

    {/* Inherited from 'Dashboard.jsx' */}
    const [userEmail, setUserEmail] = useState(null);

    useEffect(() => {
        // Set up a listener for changes in authentication state
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                // If user is logged in, set the email in state
                setUserEmail(user.email);
            } else {
                // If no user is logged in, set the email to null
                setUserEmail(null);
            }
        });

        // Cleanup function to unsubscribe from the listener when the component unmounts
        return () => unsubscribe();
    }, []);

    // Function to handle user logout
    const logout = async () => {
        try {
            // Sign out the user
            await signOut(auth);
            // Redirect to the landing page
            window.location.href = '/';
        } catch (err) {
            // Log any errors that occur during logout
            console.log(err);
        }
    };
    
    return (
        <>
            {/* Wrapper for the search page */}
            <div className="search-page-wrap">

                {/* Inherited from 'Dashboard.jsx' and 'Dashboard.css' */}
                <div className="navBar">
                    {/* FDM Logo */}
                    <div className="fdmLogo"><a href='/'><img src={fdmLogo} alt="FDM Logo"></img></a></div>
                    {/* Profile Link */}
                    <a href='/Profile' className="profileScrnBtn">Profile</a>
                    {/* Search Link */}
                    <a href='/Search' className="searchScrnBtn">Search</a>
                    {/* Listing Link */}
                    <a href='/MOL' className="searchScrnBtn">Listing</a>
                    {/* Complaints Link */}
                    <a href='/Complaint' className="complaintsScrnBtn">Complaints</a>
                    {/* Chat Link */}
                    <a href='/Chat' className='Chatbtn'>Chat</a>
                    {/* User Email */}{/* Profile Picture */}
                    <div className='userinfo'>
                        <p className='userEmail'>{userEmail}</p>
                        <div className='dashboardProfPic'><a href='/Profile'><img src={profilePic} alt="Profile pic"/></a></div>
                    </div>
                    {/* Logout Button */}
                    <button onClick={logout} className="logOutBtn">Log Out</button>
                    {/* Log out button only returns to landing page, does NOT end session */}
                </div>

                {/* Search box container */}
                <div className="search-box">
                    {/* Text above the search box */}
                    <p className="search-ent-txt-above">Enter a location</p>
                    {/* Search input and button */}
                    <div className="search-fns">
                        <input type="text" placeholder="e.g. 'London', 'NW3 5TY'" className="search-input" />
                        <button className="search-page-btn">
                            <a href='/SearchResults'>Search</a>
                        </button>
                    </div>
                </div>

            </div>
        </>
    )
}
