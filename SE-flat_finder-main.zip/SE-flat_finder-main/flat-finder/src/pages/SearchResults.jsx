import React, { useState, useEffect } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../config/firebase";
import { Link } from "react-router-dom";
import "./SearchResults.css";

import { auth } from '../config/firebase';
import { signOut } from 'firebase/auth';

import fdmLogo from '../images/landingpage_img/fdm_logo.png';
import profilePic from '../images/profile_img/profile_pic.png';

export const SearchResults = () => {
  // Inherited from 'Dashboard.jsx'
  const [userEmail, setUserEmail] = useState(null);

  useEffect(() => {
      // Set up a listener for changes in authentication state
      const unsubscribe = auth.onAuthStateChanged((user) => {
          if (user) {
              // If user is logged in, set the email in state
              setUserEmail(user.email);
          } else {
              // If no user is logged in, set the email to null
              setUserEmail(null);
          }
      });

      // Cleanup function to unsubscribe from the listener when the component unmounts
      return () => unsubscribe();
  }, []);

  // Function to handle user logout
  const logout = async () => {
      try {
          // Sign out the user
          await signOut(auth);
          // Redirect to the landing page
          window.location.href = '/';
      } catch (err) {
          // Log any errors that occur during logout
          console.log(err);
      }
  };

  // Filters
  const initialFilters = {
    location: "",
    bedrooms: "",
    bathrooms: "",
    priceRange: "",
    lengthOfStay: "",
    isFDMHost: "",
    postcode: "",
    zoneNumber: "", // Added filter for Zone number
  };

  const [listings, setListings] = useState([]);
  const [filters, setFilters] = useState(initialFilters);

  useEffect(() => {
    fetchListings();
  }, []);

  const fetchListings = async () => {
    try {
      const listingsRef = collection(db, "listings");
      const querySnapshot = await getDocs(listingsRef);
      const listingsArray = [];

      querySnapshot.forEach((doc) => {
        const data = doc.data();
        let skipListing = false;

        for (const key in data) {
          if (!data[key] || (typeof data[key] === "string" && data[key].trim() === "")) {
            skipListing = true;
            break;
          }
        }

        if (!skipListing) {
          listingsArray.push({ id: doc.id, ...data, currentImageIndex: 0 });
        }
      });

      setListings(listingsArray);
    } catch (error) {
      console.error("Error fetching listings:", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const filterListings = () => {
    return listings.filter((listing) => {
      return (
        (filters.location === "" || listing.location.toLowerCase().includes(filters.location.toLowerCase())) &&
        (filters.bedrooms === "" || parseInt(listing.bedrooms) === parseInt(filters.bedrooms)) &&
        (filters.bathrooms === "" || parseInt(listing.bathrooms) === parseInt(filters.bathrooms)) &&
        (filters.priceRange === "" || checkPriceRange(listing.price, filters.priceRange)) &&
        (filters.lengthOfStay === "" || listing.shortOrLongStay === filters.lengthOfStay) &&
        (filters.isFDMHost === "" || listing.isFDMHost === filters.isFDMHost) &&
        (filters.postcode === "" || listing.postcode === filters.postcode) &&
        (filters.zoneNumber === "" || listing.zoneNumber === filters.zoneNumber) // Filter for Zone number
      );
    });
  };

  const checkPriceRange = (price, range) => {
    const [minPrice, maxPrice] = range.split("-");
    return price >= parseInt(minPrice) && price <= parseInt(maxPrice);
  };

  const handleSearch = () => {
    const filteredListings = filterListings();
    setListings(filteredListings);
  
    // Check if filtered listings is empty
    if (filteredListings.length === 0) {
      alert("No listings match your search criteria. Please try again.");
    }
  };

  const handleReset = () => {
    setFilters(initialFilters);
    fetchListings(); // Fetch all listings again after resetting filters
  };

  return (
    <>
      {/* Navigation Bar */}
      <div className="navBar">
          <div className="fdmLogo"><a href='/'><img src={fdmLogo} alt="FDM Logo"></img></a></div>
          <a href='/Profile' className="profileScrnBtn">Profile</a>
          <a href='/Search' className="searchScrnBtn">Search</a>
          <a href='/MOL' className="searchScrnBtn">Listing</a>
          <a href='/Complaint' className="complaintsScrnBtn">Complaints</a>
          <a href='/Chat' className='Chatbtn'>Chat</a>
          <div className='userinfo'>
              <p className='userEmail'>{userEmail}</p>
              <div className='dashboardProfPic'><a href='/Profile'><img src={profilePic} alt="Profile pic"/></a></div>
          </div>
          <button onClick={logout} className="logOutBtn">Log Out</button>
      </div>

      {/* Filter header bar */}
      <div className="res-filter-bar">
        <div className="res-search">
          <p>Enter a location</p>
          <input type="text" className="res-search-input" name="location" placeholder="e.g. London" value={filters.location} onChange={handleInputChange} />
          <button className="res-search-btn" onClick={handleSearch}>Search</button>
          <button className="res-reset-btn" onClick={handleReset}>Reset</button>
        </div>

        <div className="res-bedrooms">
          <p>No. of bedrooms</p>
          <select name="bedrooms" value={filters.bedrooms} onChange={handleInputChange}>
            <option value="">Any</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
        </div>

        <div className="res-bathrooms">
          <p>No. of bathrooms</p>
          <select name="bathrooms" value={filters.bathrooms} onChange={handleInputChange}>
            <option value="">Any</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
        </div>

        <div className="res-price-range">
          <p>Price per month</p>
          <select name="priceRange" value={filters.priceRange} onChange={handleInputChange}>
            <option value="">Any</option>
            <option value="0-500">£0-£500</option>
            <option value="500-1000">£500-£1000</option>
            <option value="1000-1500">£1000-£1500</option>
            <option value="1500-2000">£1500-£2000</option>
            <option value="2000-2500">£2000-£2500</option>
            <option value="2500-3000">£2500-£3000</option>
          </select>
        </div>
        
        <div className="res-length-of-stay">
          <p>Length of stay</p>
          <select name="lengthOfStay" value={filters.lengthOfStay} onChange={handleInputChange}>
            <option value="">Any</option>
            <option value="Short">Short</option>
            <option value="Long">Long</option>
          </select>
        </div>
        
        <div className="res-is-fdm-host">
          <p>Is FDM Host</p>
          <select name="isFDMHost" value={filters.isFDMHost} onChange={handleInputChange}>
            <option value="">Any</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </select>
        </div>

        <div className="res-postcode">
          <p>Postcode</p>
          <input type="text" name="postcode" value={filters.postcode} onChange={handleInputChange} />
        </div>

        <div className="res-zone-number">
          <p>Zone number</p>
          <input type="text" name="zoneNumber" value={filters.zoneNumber} onChange={handleInputChange} />
        </div>
      </div>

      {/* Listings */}
      {listings.map((listing, index) => (
        <div key={listing.id} className="listing-card">
          <h3 className="listing-title">{listing.title}</h3>
          <div className="listing-details">
            <p>Description: {listing.description}</p>
            <p>Price per Month: £{listing.price}</p>
            <p>Location: {listing.location}</p>
            <p>Number of Bedrooms: {listing.bedrooms}</p>
            <p>Number of Bathrooms: {listing.bathrooms}</p>
            <p>Length of Stay: {listing.shortOrLongStay}</p>
            <p>Is FDM Host: {listing.isFDMHost}</p>
            <p>Postcode: {listing.postcode}</p>
            <p>Zone number: {listing.zoneNumber}</p> {/* Display Zone number */}
            <div>
              <h4 className="image-header">Image/s</h4>
              <div className="image-container">
                {listing.imagePreviews.map((image, imageIndex) => (
                  <img
                    key={imageIndex}
                    src={image}
                    alt={`Listing Image ${imageIndex}`}
                    className="listing-image"
                    style={{ maxWidth: "200px", maxHeight: "200px" }}
                  />
                ))}
              </div>
            </div>
            <span><b>Link:</b> <a href={listing.link} target="_blank" rel="noopener noreferrer">{listing.link}</a></span>
            {listing.imagePreviews.length > 1 && (
              <div className="image-navigation">
              </div>
            )}
          </div>
        </div>
      ))}
    </>
  );
};

export default SearchResults;











