import React, { useState, useEffect } from 'react';
import { auth, db } from '../config/firebase';
import { signOut } from 'firebase/auth';
import { doc, updateDoc, getDoc, collection, getDocs } from 'firebase/firestore'; // Importing collection and getDocs

import fdmLogo from '../images/landingpage_img/fdm_logo.png';
import profilePic from '../images/profile_img/profile_pic.png';
import instagram from '../images/profile_img/instagram.png';
import twitter from '../images/profile_img/twitter.png';
import linkedin from '../images/profile_img/linked_in.png';
import "./SetupProfile.css";

export const SetupProfile = () => {
    const [userEmail, setUserEmail] = useState(null);
    const [userData, setUserData] = useState({
        name: '',
        'phone-num': '',
        'hobby-one': '',
        'hobby-two': '',
        'hobby-three': '',
        'pref-pet': false,
        'pref-smoke': false,
        });
    const [docId, setDocId] = useState(null); // State to store the document ID

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged(async (user) => {
            if (user) {
                setUserEmail(user.email);
                await fetchUserData(user);
            } else {
                setUserEmail(null);
            }
        });
        return () => unsubscribe();
    }, []);

    const fetchUserData = async (user) => {
        try {
            const collRef = collection(db, 'Profiles');
            const querySnapshot = await getDocs(collRef);
            querySnapshot.forEach((doc) => {
                const userData = doc.data();
                if (userData['email-ad'] === user.email) {
                    setUserData(userData);
                    setDocId(doc.id); // Set the document ID
                    return;
                }
            });
        } catch (error) {
            console.error('Error fetching data', error);
        }
    };

    const logout = async () => {
        try {
            await signOut(auth);
            window.location.href = '/';
        } catch (err) {
            console.log(err);
        }
    };

    const handleSaveChanges = async () => {
        try {
            const docRef = doc(db, 'Profiles', docId); // Get the reference to the document using the document ID
            await updateDoc(docRef, userData); // Update the document with the new user data
            console.log('Profile updated successfully!');
        } catch (error) {
            console.error('Error updating profile', error);
        }
    };

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        if (name !== 'email') {
            setUserData(prevData => ({
                ...prevData,
                [name]: type === 'checkbox' ? checked : value
            }));
        }
    };

    return (
        <div className="profile-edit-wrap">
            <div className="navBar">
                <div className="fdmLogo"><a href='/'><img src={fdmLogo} alt="FDM Logo" /></a></div>
                <a href='/Profile' className="profileScrnBtn">Profile</a>
                <a href='/Search' className="searchScrnBtn">Search</a>
                <a href='/MOL' className="searchScrnBtn">Listing</a>
                <a href='/Complaint' className="complaintsScrnBtn">Complaints</a>
                <a href='/Chat' className='Chatbtn'>Chat</a>
                <div className='userinfo'>
                    <p className='userEmail'>{userEmail}</p>
                    <div className='dashboardProfPic'><a href='/Profile'><img src={profilePic} alt="Profile pic" /></a></div>
                </div>
                <button onClick={logout} className="logOutBtn">Log Out</button>
            </div>
            <div className="profile-main">
                <h1 className="profile-title">Your Profile</h1>
                <p className="profile-title-description"><img src={profilePic} alt="profile-pic" /><br />
                    <h2>{userData.name}</h2>
                    <input
                        type="text"
                        name="name"
                        value={userData.name}
                        placeholder="Enter Name"
                        className="profile-edit-name-entry"
                        onChange={handleChange}
                    />
                </p>
                <h2>
                    <button onClick={handleSaveChanges} className="profile-edit-profile-btn">
                        Save Changes
                    </button>
                </h2>
            </div>
            <div className="profile-info-one">
                <div className="profile-contact-info">
                    <h2>Contact Info</h2>
                    <ul>
                        <li>
                            Phone Number:
                            <input
                                type="text"
                                name="phone-num"
                                value={userData['phone-num']}
                                placeholder="e.g. +44 7367 678245"
                                className="profile-edit-num-entry"
                                onChange={handleChange}
                            />
                        </li>
                    </ul>
                </div>
                <div className="profile-hobbies">
                    <h2>Hobbies</h2>
                    <ul>
                        <li>
                            <input
                                type="text"
                                name="hobby-one"
                                value={userData['hobby-one']}
                                placeholder="Hobby 1"
                                className="profile-edit-hobby-one-entry"
                                onChange={handleChange}
                            />
                        </li>
                        <li>
                            <input
                                type="text"
                                name="hobby-two"
                                value={userData['hobby-two']}
                                placeholder="Hobby 2"
                                className="profile-edit-hobby-two-entry"
                                onChange={handleChange}
                            />
                        </li>
                        <li>
                            <input
                                type="text"
                                name="hobby-three"
                                value={userData['hobby-three']}
                                placeholder="Hobby 3"
                                className="profile-edit-hobby-three-entry"
                                onChange={handleChange}
                            />
                        </li>
                    </ul>
                </div>
                <div className="profile-prefer">
                    <h2>Preferences</h2>
                    <ul>
                        <li>
                            Smoking:
                            <input
                                type="checkbox"
                                name="pref-smoke"
                                checked={userData['pref-smoke']}
                                className="profile-edit-smoking"
                                onChange={handleChange}
                            />
                        </li>
                        <li>
                            Pets:
                            <input
                                type="checkbox"
                                name="pref-pet"
                                checked={userData['pref-pet']}
                                className="profile-edit-pets"
                                onChange={handleChange}
                            />
                        </li>
                    </ul>
                </div>
            </div>
            <div className="profile-info-two">
                <div className="profile-soc-med">
                    <h2>Social Media</h2>
                    <div className="profile-soc-med-links">
                        <a href="instagram.com">
                            <img className="socmed-icon" src={instagram} alt="instagram" />
                        </a>
                        <a href="x.com">
                            <img className="socmed-icon" src={twitter} alt="twitter" />
                        </a>
                        <a href="linkedin.com">
                            <img className="socmed-icon" src={linkedin} alt="linkedin" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SetupProfile;
