import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth ,db } from '../config/firebase'

import { useState } from 'react'

import './Signin.css'

import x_icon from '../images/landingpage_img/x_icon.png'
import FDM_logo from '../images/landingpage_img/fdm_logo.png'
import { collection, query, where, getDocs } from '@firebase/firestore'


export const Signin = () => {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState(null);

    const login = async() => {
        try {
            await signInWithEmailAndPassword(auth, email, password);
   
            const userType = await user_type();
    
            switch (userType) {
                case 'employee':
                    window.location.href = '/Dashboard';
                    break;
                case 'admin':
                    window.location.href = '/AdminDashboard';
                    break;
                case 'landlord':
                    window.location.href = '/LandlordDashboard';
                    break;
                
            }
    
        } catch (err) {
            setError(err.code);
        }
    };
    

    const user_type = async () => {
        try {
            const currentUser = auth.currentUser;
            if (!currentUser) {
                throw new Error('User not logged in');
            }
    
            const currentEmail = currentUser.email;
            console.log(currentEmail);
    
            const collRef = collection(db, 'Users');
            const q = query(collRef, where('email', '==', currentEmail));
            const querySnapshot = await getDocs(q);
    
            if (!querySnapshot.empty) {
                const doc = querySnapshot.docs[0];
                const userType = doc.data().usertype;
                return userType;
            } else {
                throw new Error('No matching document found');
            }
        } catch (error) {
            console.error('Error retrieving user type:', error);
            return null;
        }
    };
    

    const handleErrorMessage = (errorCode) => {
        switch (errorCode) {
            case 'auth/invalid-email':
                return 'Invalid email. Please enter a valid email address.';
            case 'auth/missing-password':
                return 'Invalid password. Please make sure to enter a password.';
            case 'auth/weak-password':
                return 'invalid password. Please enter a stronger password.';
            case 'auth/email-already-in-use':
                return 'invalid email. Email already in use.';
            case 'auth/invalid-credential':
                return 'invalid credentials. Check both email & password.';       
            default:
                return 'An error occurred. Please try again later.';
        }
    };

    return (
        <div className='signin-bg'>
            <img src={FDM_logo} alt="fdm_logo" className='signin-FDM-logo'/>
            <div className='signin-card'>
                <a href="/" className='signin-x-btn'><img src={x_icon} alt="x" className='signin-x-img'/></a>
                <h1 className="signin-title">Sign in</h1>
                <p className="signin-description">Sign in to access your account.</p>
                <input type="text" placeholder='Enter Email' className='signin-email' onChange={(e) => setEmail(e.target.value)}/>
                <input type="text" placeholder='Enter password' className='signin-password' onChange={(e) => setPassword(e.target.value)}/>
                <button className="signin-btn" onClick={login}>Sign in</button>
                {error && <p className="signin-error">{handleErrorMessage(error)}</p>}
                <p>Don't have an account? <a href='/Signup' className='to-signup'>Sign Up</a></p>
            </div>
        </div>
    )
}