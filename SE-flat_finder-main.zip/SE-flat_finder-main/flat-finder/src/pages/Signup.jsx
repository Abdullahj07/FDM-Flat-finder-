import { auth, db } from '../config/firebase'
import { createUserWithEmailAndPassword, signOut } from 'firebase/auth'
import { useState, useEffect } from 'react'


import './Signup.css'

import x_icon from '../images/landingpage_img/x_icon.png'
import FDM_logo from '../images/landingpage_img/fdm_logo.png'
import { addDoc, collection } from '@firebase/firestore'


export const Signup = () => {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState(null);

    const createUser = async () => {
        try {
            await createUserWithEmailAndPassword(auth, email, password);
    
            await addToDb();
    
            window.location.href = '/LandlordDashboard';
        } catch (err) {
            setError(err.code);
        }
    };
    
    const addToDb = async () => {
        try {
            const currentUser = auth.currentUser;
            if (!currentUser) {
                throw new Error('User not logged in');
            }
    
            const currentEmail = currentUser.email;
            const collRef = collection(db, 'Users');
            await addDoc(collRef, {
                email: currentEmail,
                usertype: 'landlord',
                userID: auth.currentUser.uid
            });
        } catch (error) {
            console.error('Error adding user to database:', error);
            throw error;
        }
    };
    

    const handleErrorMessage = (errorCode) => {
        switch (errorCode) {
            case 'auth/invalid-email':
                return 'Invalid email. Please enter a valid email address.';
            case 'auth/missing-password':
                return 'Invalid password. Please make sure to enter a password.';
            case 'auth/weak-password':
                return 'invalid password. Please enter a stronger password.';
            case 'auth/email-already-in-use':
                return 'invalid email. Email already in use.';
            case 'auth/invalid-credential':
                return 'invalid credentials. Check both email & password.';       
            default:
                return 'An error occurred. Please try again later.';
        }
    };
    

    return (
        <div className='signup-bg'>
            <img src={FDM_logo} alt="fdm_logo" className='signup-FDM-logo'/>
            <div className='signup-card'>
                <a href="/" className='signup-x-btn'><img src={x_icon} alt="x" className='signup-x-img'/></a>
                <h1 className="signup-title">Sign up</h1>
                <p className="signup-description">Sign up as independant flat lister.</p>
                <input type="text" placeholder='Enter Email' className='signup-email' onChange={(e) => setEmail(e.target.value)}/>
                <input type="text" placeholder='Enter password' className='signup-password' onChange={(e) => setPassword(e.target.value)}/>
                <button className="signup-btn" onClick={createUser}>Sign up</button>
                {error && <p className="signin-error">{handleErrorMessage(error)}</p>}
                <p>Already have an account? <a href='/Signin' className='to-signin'>Sign in</a></p>
            </div>
        </div>
    )
}