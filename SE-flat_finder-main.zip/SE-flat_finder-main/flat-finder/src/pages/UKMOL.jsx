import React, { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { Link } from "react-router-dom";
import { db } from "../config/firebase";
import './MOL.css'
import {
  FormControl,
  FormLabel,
  Input,
  Textarea,
  Button,
  Box,
  Heading,
  Image,
  Stack,
  IconButton,
} from "@chakra-ui/react";
import { CloseIcon } from "@chakra-ui/icons";
import "./MOL.css";

export const UKMOL = () => {
  const [imagePreviews, setImagePreviews] = useState([]);
  const [listingData, setListingData] = useState({
    title: "",
    description: "",
    price: "",
    location: "",
    bedrooms: "",
    bathrooms: "",
    link: "", // New state variable for link
    shortOrLongStay: "", // New state variable for short or long stay
    isFDMHost: "", // New state variable for is FDM host
    postcode: "", // New state variable for postcode
    zoneNumber: "", // New state variable for zone number
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setListingData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newListing = {
        ...listingData,
        createdAt: serverTimestamp(),
        imagePreviews: imagePreviews,
      };
      await addListingToDB(newListing);
      alert("Listing added successfully!");
      e.target.reset();
      setImagePreviews([]);
      setListingData({
        title: "",
        description: "",
        price: "",
        location: "",
        bedrooms: "",
        bathrooms: "",
        link: "", // Reset link field
        shortOrLongStay: "", // Reset short or long stay field
        isFDMHost: "", // Reset is FDM host field
        postcode: "", // Reset postcode field
        zoneNumber: "", // Reset zone number field
      });
    } catch (error) {
      console.error("Error adding listing: ", error);
      alert("An error occurred. Please check the console for details.");
    }
  };

  const addListingToDB = async (listing) => {
    try {
      const listingsRef = collection(db, "listings");
      await addDoc(listingsRef, listing);
    } catch (error) {
      console.error("Error adding listing to database: ", error);
      throw error;
    }
  };

  const handleImageChange = (e) => {
    const files = e.target.files;
    const newPreviews = [];

    for (let i = 0; i < files.length; i++) {
      const reader = new FileReader();
      reader.onload = (event) => {
        newPreviews.push(event.target.result);
        if (newPreviews.length === files.length) {
          setImagePreviews([...imagePreviews, ...newPreviews]);
        }
      };
      reader.readAsDataURL(files[i]);
    }
  };

  const handleRemoveImage = (index) => {
    setImagePreviews(imagePreviews.filter((_, i) => i !== index));
  };

  return (
    <Box className="container" maxW="1000px" mx="auto">
      <Heading as="h1" className="form-title">
        London Create Your Own Listing
      </Heading>
      <form onSubmit={handleSubmit}>
        <FormControl className="form-input" mb={4}>
          <FormLabel>Title</FormLabel>
          <Input
            type="text"
            placeholder="Enter title"
            className="custom-input"
            required
            name="title"
            value={listingData.title}
            onChange={handleInputChange}
          />
        </FormControl>

        <FormControl className="form-input" mb={4}>
          <FormLabel>Description</FormLabel>
          <Textarea
            placeholder="Enter description"
            className="custom-input"
            required
            name="description"
            value={listingData.description}
            onChange={handleInputChange}
          />
        </FormControl>

        <FormControl className="form-input" mb={4}>
          <FormLabel>Price Per Month</FormLabel>
          <Input
            type="number"
            placeholder="Enter price"
            className="custom-input"
            required
            name="price"
            value={listingData.price}
            onChange={handleInputChange}
          />
        </FormControl>

        <FormControl className="form-input" mb={4}>
          <FormLabel>Location</FormLabel>
          <Input
            type="text"
            placeholder="Enter location"
            className="custom-input"
            required
            name="location"
            value={listingData.location}
            onChange={handleInputChange}
          />
        </FormControl>

        <FormControl className="form-input" mb={4}>
          <FormLabel>Number of Bedrooms</FormLabel>
          <Input
            type="number"
            placeholder="Enter number of bedrooms"
            className="custom-input"
            required
            name="bedrooms"
            value={listingData.bedrooms}
            onChange={handleInputChange}
          />
        </FormControl>

        <FormControl className="form-input" mb={4}>
          <FormLabel>Number of Bathrooms</FormLabel>
          <Input
            type="number"
            placeholder="Enter number of bathrooms"
            className="custom-input"
            required
            name="bathrooms"
            value={listingData.bathrooms}
            onChange={handleInputChange}
          />
        </FormControl>

        <FormControl className="form-input" mb={4}>
          <FormLabel>Link</FormLabel>
          <Input
            type="text"
            placeholder="Enter link"
            className="custom-input"
            required
            name="link"
            value={listingData.link}
            onChange={handleInputChange}
          />
        </FormControl>

        <FormControl className="form-input" mb={4}>
          <FormLabel>Image/s</FormLabel>
          <Input
            type="file"
            accept="image/*"
            className="custom-input"
            required
            multiple
            onChange={handleImageChange}
          />
        </FormControl>

        <Stack spacing={4} mb={6}>
          {imagePreviews.map((preview, index) => (
            <Box key={index} display="flex" alignItems="center">
              <Image src={preview} alt={`Image Preview ${index}`} maxW="200px" maxH="200px" />
              <IconButton icon={<CloseIcon />} aria-label="Remove" onClick={() => handleRemoveImage(index)} className="close-icon" />
            </Box>
          ))}
        </Stack>

        {/* New field for Short or Long Stay */}
        <FormControl className="form-input" mb={4}>
          <FormLabel>Short or Long Stay </FormLabel>
          <select
            className="custom-input"
            required
            name="shortOrLongStay"
            value={listingData.shortOrLongStay}
            onChange={handleInputChange}
          >
            <option value="">Select an option</option>
            <option value="Short">Short</option>
            <option value="Long">Long</option>
          </select>
        </FormControl>

        {/* New field for Is FDM Host */}
        <FormControl className="form-input" mb={4}>
          <FormLabel>Is FDM Host</FormLabel>
          <select
            className="custom-input"
            required
            name="isFDMHost"
            value={listingData.isFDMHost}
            onChange={handleInputChange}
          >
            <option value="">Select an option</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </select>
        </FormControl>

        {/* New field for Postcode */}
        <FormControl className="form-input" mb={4}>
          <FormLabel>Postcode</FormLabel>
          <Input
            type="text"
            placeholder="Enter postcode"
            className="custom-input"
            required
            name="postcode"
            value={listingData.postcode}
            onChange={handleInputChange}
          />
        </FormControl>

        {/* New field for Zone number */}
        <FormControl className="form-input" mb={4}>
          <FormLabel>Zone number</FormLabel>
          <Input
            type="text"
            placeholder="Enter zone number"
            className="custom-input"
            required
            name="zoneNumber"
            value={listingData.zoneNumber}
            onChange={handleInputChange}
          />
        </FormControl>

        <Button type="submit" className="submit-button" width="100%" fontSize="lg">
          Create Listing
        </Button>
        <a href='/CurrentListings' className='CurrentListingsScrnBtn'>All Listings</a>
        <a href='/LandlordDashboard' className='LandlordDashboardScrnBtn'>Return To Dashboard</a>
      </form>
      
    </Box>
  );
};

export default UKMOL;
