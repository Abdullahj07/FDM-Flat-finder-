import { useState, useEffect } from 'react';
import {collection, query, getDocs, where, doc, updateDoc } from 'firebase/firestore';
import { auth, db } from '../config/firebase';
import './ViewComplaint.css'
import fdmLogo from "../images/landingpage_img/fdm_logo.png";
import profilePic from "../images/profile_img/profile_pic.png";
import {signOut} from "firebase/auth";

const ViewComplaint = () => {
    const [userType, setUserType] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [complaints, setComplaints] = useState([]);
    const [landlordUserEmail, setLandlordUserEmail] = useState([]);

    // navBar
    const [userEmail, setUserEmail] = useState(null);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                setUserEmail(user.email);
            } else {
                setUserEmail(null);
            }
        });

        return () => unsubscribe();
    }, []);

    const logout = async () => {
        try {
            await signOut(auth);
            window.location.href = '/';
        } catch (err) {
            console.error(err);
        }
    };

    // Check if user is logged in
    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged(user => {
            setCurrentUser(user);
        });

        return unsubscribe;
    }, []);

    useEffect(() => {
        const fetchUserType = async () => {
            if (!currentUser) {
                return;
            }

            const q = query(collection(db, "Users"), where("userID", "==", currentUser.uid));
            const querySnapshot = await getDocs(q);

            if (!querySnapshot.empty) {
                const userType = querySnapshot.docs[0].data().usertype;
                setUserType(userType);
                if (userType === 'landlord') {
                    setLandlordUserEmail(querySnapshot.docs[0].data().email); // Set landlordUserEmail to email
                }
            }
        };

        fetchUserType();
    }, [currentUser]);



    // Fetch complaints
    useEffect(() => {
        const fetchComplaints = async () => {
            // Check if currentUser is null
            if (!currentUser) {
                return;
            }

            let complaintsCollectionRef = collection(db, "Complaints");

            // If user type is 'landlord', only fetch complaints where receiverEmail matches landlordUserEmail
            if (userType === 'landlord' && landlordUserEmail) {
                complaintsCollectionRef = query(complaintsCollectionRef, where("receiverEmail", "==", landlordUserEmail));
            }
            else if (userType !== 'admin') {
                complaintsCollectionRef = query(complaintsCollectionRef, where("receiverEmail", "==", currentUser.email));
            }

            const complaintsSnapshot = await getDocs(complaintsCollectionRef);

            // Include the document ID in the complaint data
            const complaintsData = complaintsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setComplaints(complaintsData);
        };
        fetchComplaints();
    }, [userType, landlordUserEmail, currentUser]);

    // Function to handle status change
    const handleStatusChange = async (complaintId, currentStatus) => {
        const complaintRef = doc(db, "Complaints", complaintId);
        await updateDoc(complaintRef, {
            status: !currentStatus
        });

        // Update the complaints state
        setComplaints(complaints.map(complaint => {
            if (complaint.id === complaintId) {
                // This is the complaint that was updated, return a new object with the updated status
                return { ...complaint, status: !currentStatus };
            } else {
                // This is not the complaint that was updated, return it as is
                return complaint;
            }
        }));
    }

    return (
        <div className="ViewComplaint">
            <div className="navBar">
                <div className="fdmLogo"><a href='/'><img src={fdmLogo} alt="FDM Logo"></img></a></div>
                <a href='/Profile' className="profileScrnBtn">Profile</a>
                {userType === 'admin' && <a href='/RemoveListings' className="ListingScrnBtn">Listing</a>}
                {userType === 'landlord' && <a href='/MOL' className='MOLScrnBtn'>Make Own Listing</a>}
                <a href='/Complaint' className="complaintsScrnBtn">Complaints</a>
                <a href='/Chat' className='Chatbtn'>Chat</a>
                <div className='userinfo'>
                    <p className='userEmail'>{userEmail}</p>
                    <div className='dashboardProfPic'><a href='/Profile'><img src={profilePic} alt="Profile pic"/></a>
                    </div>
                </div>
                <button onClick={logout} className="logOutBtn">Log Out</button>
            </div>
            <h1>Complaints Received</h1>

            {complaints.map((complaint, index) => {
                return (
                    <div key={index} className="complaint-box">
                        <p>Sender Email: {complaint.userEmail}</p>
                        <p>Receiver Email: {complaint.receiverEmail}</p>
                        <p>Reason: {complaint.reason}</p>
                        <p>Details: {complaint.details}</p>
                        <p>Time: {new Date(complaint.timestamp?.seconds * 1000).toLocaleString()}</p>
                        <p>Status: {complaint.status ? 'Resolved' : 'Pending'}</p>
                        <div className="action-container">
                            <button className='Message' onClick={() => window.location.href = `/Chat?userID=${complaint.userID}`}>Message
                            </button>
                            {userType === 'admin' && (
                                <div>
                                    <label>
                                        <input
                                            className="status-checkbox"
                                            type="checkbox"
                                            checked={complaint.status}
                                            onChange={() => handleStatusChange(complaint.id, complaint.status)}
                                        />
                                        Mark as Resolved
                                    </label>
                                </div>
                            )}
                        </div>

                    </div>

                )
            })}


        </div>
    );
};

export default ViewComplaint;